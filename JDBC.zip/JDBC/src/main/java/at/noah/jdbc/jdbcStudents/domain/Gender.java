package at.noah.jdbc.jdbcStudents.domain;

public enum Gender {
    MALE, FEMALE, DIVERSE
}
